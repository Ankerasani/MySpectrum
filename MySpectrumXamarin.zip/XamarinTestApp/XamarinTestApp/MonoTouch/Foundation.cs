﻿namespace MonoTouch
{
    internal class Foundation
    {
        internal class NSRange
        {
        }
    }
}